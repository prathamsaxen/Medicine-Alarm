import React from 'react'
import Navbar from '../Common/Navbar'
const Contact = () => {
  return (
    <div>
      <Navbar/>
      Contact</div>
  )
}

export default Contact
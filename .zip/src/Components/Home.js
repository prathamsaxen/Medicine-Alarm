import React from 'react'
import Hero from '../Common/Hero'
import Navbar from '../Common/Navbar'
const Home = () => {
  return (
    <div>
      <Navbar/>
        <Hero/>
    </div>
  )
}

export default Home
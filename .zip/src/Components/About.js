import React from 'react'
import Navbar from '../Common/Navbar'
const About = () => {
  return (
    <div>
      <Navbar/>
      About</div>
  )
}

export default About